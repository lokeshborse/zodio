// Country code with flag
$("#mobile").intlTelInput({
    initialCountry: "us",
    separateDialCode: true,
});